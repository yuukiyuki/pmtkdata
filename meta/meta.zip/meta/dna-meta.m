% PMTKdescription DNA sequences 
% PMTKsource
% PMTKtype
% PMTKncases 10 
% PMTKndims 30
