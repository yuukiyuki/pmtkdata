% PMTKdescription Height vs weight data for two groups: men and women
% PMTKsource http://www.stat.psu.edu/resources/bydata.htm
% PMTKtype Binary Classification
% PMTKncases 200
% PMTKndims 2
