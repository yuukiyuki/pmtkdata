% PMTKdescription 2004 New Car and Truck Data
% PMTKsource Kiplinger's Personal Finance, December 2003, vol. 57, no. 12, pp. 104-123 www.kiplinger.com
% PMTKtypeX mixed
% PMTKtypeY discrete
% PMTKncases 428
% PMTKndims 19
