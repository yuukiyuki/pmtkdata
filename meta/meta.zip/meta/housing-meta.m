% PMTKdescription Boston housing data from UCI repository
% PMTKsource http://archive.ics.uci.edu/ml/support/Housing
% PMTKtype Regression 
% PMTKncases 300
% PMTKndims 13
