% PMTKdescription Old faithful Geiser data set
% PMTKsource http://research.microsoft.com/en-us/um/people/cmbishop/PRML/webdatasets/datasets.htm
% PMTKtype 
% PMTKncases 272
% PMTKndims 2
