% PMTKdescription Iris species classification data
% PMTKsource Built in to the MATLAB statistics toolbox
% PMTKtype Classification
% PMTKncases 150
% PMTKndims 4
