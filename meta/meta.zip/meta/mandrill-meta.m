% PMTKdescription An image of a mandrill
% PMTKsource Built in to MATLAB
% PMTKtype
% PMTKncases
% PMTKndims 512x512
