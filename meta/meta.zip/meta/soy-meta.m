% PMTKdescription UCI Soybean data set
% PMTKsource http://archive.ics.uci.edu/ml/datasets/Soybean+(Large)
% PMTKtype Classification 
% PMTKncases 307
% PMTKndims 35
