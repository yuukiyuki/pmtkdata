% PMTKdescription 32x32 binary Image of letter X (0/1)
% PMTKsource http://www.cs.ubc.ca/~schmidtm/Software/UGM
% PMTKtypeX Binary
% PMTKtypeY
% PMTKncases 1
% PMTKndims  1024