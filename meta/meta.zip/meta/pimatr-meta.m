% PMTKdescription Diabetes in Pima Indian Women
% PMTKsource R built in dataset 
% PMTKtype Binary Classification
% PMTKncases 200
% PMTKndims 8
