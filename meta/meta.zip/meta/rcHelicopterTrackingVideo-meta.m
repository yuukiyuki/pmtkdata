% PMTKdescription AVI movie of autonomous remote controlled helicopter
% PMTKsource http://www-robotics.usc.edu/~avatar/clips/landingvideos/second.avi
% Used by pfColorTrackerDemo from
% http://www.mathworks.com/matlabcentral/fileexchange/17960
