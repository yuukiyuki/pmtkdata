% PMTKdescription Various images of the letter A
% PMTKsource
% PMTKtype 
% PMTKncases 4
% PMTKndims 128x128
