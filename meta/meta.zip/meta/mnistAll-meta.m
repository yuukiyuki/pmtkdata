% PMTKdescription MNIST handwritten digits
% PMTKsource http://yann.lecun.com/exdb/mnist
% PMTKcreated mnistMakeAll.m
% PMTKtypeX 0-255 gray scale images
% PMTKtypeY 0-9 class labels  of digits
% PMTKncases 60000
% PMTKndims 28x28
% PMTKcontributedBy Yann Le Cun