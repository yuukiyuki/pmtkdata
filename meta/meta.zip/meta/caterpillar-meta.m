% PMTKdescription Caterpillar nests data
% PMTKsource http://www.ceremade.dauphine.fr/~xian/BCS/caterpillar
% PMTKtypeX cts
% PMTKtypeY discrete
% PMTKncases 33
% PMTKndims 10
