% PMTKdescription An image of a clown
% PMTKsource Built into MATLAB
% PMTKtype
% PMTKncases 1
% PMTKndims 200x320
