% PMTKdescription Four very different data sets all with the same p-value
% PMTKsource Built in R data set
% PMTKtypeX discrete
% PMTKtypeY cts
% PMTKncases 11
% PMTKndims 1
