% PMTKdescription Prostate cancer data set
% PMTKsource http://www-stat.stanford.edu/~tibs/ElemStatLearn/
% PMTKtype Regression 
% PMTKncases 67
% PMTKndims 8
