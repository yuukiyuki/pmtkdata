% PMTKdescription All 5-node undirected graphs
% PMTKsource
% PMTKtype 
% PMTKncases 1024
% PMTKndims
