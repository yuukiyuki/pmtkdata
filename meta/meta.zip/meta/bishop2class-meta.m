% PMTKdescription Classification data set from Bishop's Pattern Recognition and Machine Learning
% PMTKsource http://research.microsoft.com/en-us/um/people/cmbishop/prml/webdatasets/datasets.htm
% PMTKtypeX cts
% PMTKtypeY binary
% PMTKncases 200
% PMTKndims 2
