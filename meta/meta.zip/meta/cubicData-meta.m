% PMTKdescription
% PMTKsource
% PMTKtype Regression
% PMTKncases 100
% PMTKndims 1
