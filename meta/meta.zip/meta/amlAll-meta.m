% PMTKdescription Molecular Classification of Cancer: Class Discovery and Class Prediction by Gene Expression
% PMTKsource http://www.broadinstitute.org/cgi-bin/cancer/datasets.cgi
% PMTKtypeX discrete
% PMTKtypeY binary
% PMTKncases 38+34
% PMTKndims 7129
% PMTKcreated processAmlAllData.m

