% PMTKdescription Synthetic correlated dice rolls from an HMM model
% PMTKcreated casinoDemo.m
% PMTKtype 
% PMTKncases 
% PMTKndims 