% PMTKdescription Normalized handwritten digits, automatically scanned from envelopes by the U.S. Postal Service
% PMTKsource http://www-stat.stanford.edu/~tibs/ElemStatLearn/data.html
% PMTKtype 
% PMTKncases 658
% PMTKndims 16x16
