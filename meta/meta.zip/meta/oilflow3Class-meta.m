% PMTKdescription Oil Flow data
% PMTKsource http://research.microsoft.com/en-us/um/people/cmbishop/PRML/webdatasets/datasets.htm
% PMTKtype Classification
% PMTKncases 1000
% PMTKndims 12
