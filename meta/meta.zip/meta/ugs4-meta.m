% PMTKdescription All 4-node undirected graphs
% PMTKsource 
% PMTKtype 
% PMTKncases 64
% PMTKndims
