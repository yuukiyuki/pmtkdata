% PMTKdescription Highly non-linear data generated from a servo system simulation
% PMTKsource http://archive.ics.uci.edu/ml/datasets/Servo
% PMTKtype Regression 
% PMTKncases 167    
% PMTKndims 4
