% PMTKdescription UCI Yeast data set: Predicting the Cellular Localization Sites of Proteins
% PMTKsource http://archive.ics.uci.edu/ml/datasets/yeast
% PMTKtype Classification 
% PMTKncases 1484
% PMTKndims 8
