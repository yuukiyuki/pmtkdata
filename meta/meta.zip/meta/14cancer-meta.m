% PMTKdescription Gene expression data for 14 types of cancer
% PMTKsource http://www-stat.stanford.edu/~tibs/ElemStatLearn/data.html
% PMTKtypeX cts
% PMTKtypeY discrete
% PMTKncases 144
% PMTKndims 16063
