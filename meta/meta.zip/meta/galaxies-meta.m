% PMTKdescription Galaxy data frame records of the radial velocity of a spiral galaxy
% PMTKsource http://www-stat.stanford.edu/~tibs/ElemStatLearn/data.html
% PMTKtype
% PMTKncases 82
% PMTKndims 1
