% PMTKdescription Leptograpsus crabs data
% PMTKsource http://www.stats.ox.ac.uk/pub/PRNN/
% PMTKtype Classification
% PMTKncases 80
% PMTKndims 5
