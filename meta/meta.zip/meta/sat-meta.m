% PMTKdescription SAT scores
% PMTKsource Johnson and Albert p77 table 3.1
% PMTKtype Binary Classification 
% PMTKncases 30 
% PMTKndims 1
