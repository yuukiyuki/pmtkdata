% PMTKdescription Classification of radar returns from the ionosphere
% PMTKsource http://archive.ics.uci.edu/ml/datasets/Ionosphere
% PMTKtype Classification
% PMTKncases 351
% PMTKndims 34
