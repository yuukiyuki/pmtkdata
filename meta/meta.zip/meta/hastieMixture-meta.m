% PMTKdescription Gaussian Mixture data used in Hastie's "Elements of Statistical Learning" figure 2.1-2.3
% PMTKsource http://www-stat.stanford.edu/~tibs/ElemStatLearn/datasets/
% PMTKtype Binary Classification
% PMTKncases 200
% PMTKndims 2
