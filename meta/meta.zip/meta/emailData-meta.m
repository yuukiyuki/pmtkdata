% PMTKdescription Email classification data
% PMTKsource
% PMTKtype Classification
% PMTKncases 1500
% PMTKndims 10000
