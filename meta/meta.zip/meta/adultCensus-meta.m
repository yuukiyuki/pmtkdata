% PMTKdescription Adult census from UCI repository
% PMTKsource http://archive.ics.uci.edu/ml/datasets/Adult
% PMTKtypeX mixed
% PMTKtypeY binary
% PMTKncases 45222
% PMTKndims 11
