% PMTKdescription All 4-node directed acyclic graphs
% PMTKcreated mk_all_dags.m
% PMTKtype 
% PMTKncases 543
% PMTKndims
