% PMTKdescription Gasch's gene expression data (contains NaNs)
% PMTKsource http://genome-www.stanford.edu/yeast_stress/data.shtml
% PMTKcreated parseYeastStressData.m
% PMTKtype Classification
% PMTKncases 174
% PMTKndims 6152


