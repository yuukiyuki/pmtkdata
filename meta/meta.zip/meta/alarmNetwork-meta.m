% PMTKdescription The alarm monitoring system 
% PMTKsource Beinlich, Ingo, H. J. Suermondt, R. M. Chavez, and G. F. Cooper (1989) "The ALARM monitoring system: A case study with two probabilistic inference techniques for belief networks" in Proc. of the Second European Conf. on Artificial Intelligence in Medicine (London, Aug.), 38, 247-256. 
% PMTKtype 
% PMTKncases
% PMTKndims
