% PMTKdescription All 5-node directed acyclic graphs
% PMTKcreated mk_all_dags.m
% PMTKtype 
% PMTKncases 29281
% PMTKndims
