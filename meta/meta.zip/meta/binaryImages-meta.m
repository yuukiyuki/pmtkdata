% PMTKdescription Small binary images
% PMTKsource Random binarized images from the web
% PMTKtype 
% PMTKncases 7
% PMTKndims 150x150
