% PMTKdescription Car evaluation database
% PMTKsource http://archive.ics.uci.edu/ml/datasets/Car+Evaluation
% PMTKtypeX binary
% PMTKtypeY discrete
% PMTKncases 1728
% PMTKndims 6
