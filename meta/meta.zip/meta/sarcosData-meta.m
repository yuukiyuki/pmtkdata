% PMTKdescription SARCOS robot arm regression data
% PMTKsource http://www.gaussianprocess.org/gpml/data/
% PMTKtype Regression
% PMTKncases 44484
% PMTKndims 21 