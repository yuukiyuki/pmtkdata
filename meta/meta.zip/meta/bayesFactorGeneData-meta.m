% PMTKdescription A synthetic data set to test detection of differential expression between genes
% PMTKcreated bayesFactorMakeGeneData.m
% PMTKtypeX cts
% PMTKtypeY binary
% PMTKncases 100
% PMTKndims 2
