% PMTKdescription Unigram and Bigram data for Darwin's "On the origin of Species"
% PMTKsource Generated from <a href = "http://www.gutenberg.org/etext/22764">this</a> text
% PMTKtype
% PMTKncases
% PMTKndims
