% PMTKdescription 32x32 color Image of letter X 
% PMTKsource http://www.cs.ubc.ca/~schmidtm/Software/UGM
% PMTKtypeX Discrete
% PMTKtypeY
% PMTKncases 1
% PMTKndims  32x32x3
% PMTKcreated XimgRbgMake.m