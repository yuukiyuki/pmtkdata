% PMTKdescription Speech signals of the numbers "four" and "five"
% PMTKsource http://people.csail.mit.edu/tommi/
% PMTKtype Binary Classification
% PMTKncases 252
% PMTKndims
