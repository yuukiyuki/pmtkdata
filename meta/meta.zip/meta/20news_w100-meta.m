% PMTKdescription 100 words from 20newsgroups data 4 meta-groups
% PMTKsource http://cs.nyu.edu/~roweis/data.html and  http://people.csail.mit.edu/jrennie/20Newsgroups/
% PMTKtypeX Sparse binary
% PMTKtypeY discrete (4)
% PMTKncases 16242
% PMTKndims 100

   documents: [100x16242 logical]
      wordlist: {1x100 cell}
    newsgroups: [1x16242 double]
    groupnames: {'comp.*'  'rec.*'  'sci.*'  'talk.*'}
