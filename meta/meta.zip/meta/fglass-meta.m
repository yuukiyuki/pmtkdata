% PMTKdescription Glass identification data set
% PMTKsource http://archive.ics.uci.edu/ml/datasets/Glass+Identification
% PMTKtype Classification
% PMTKncases 214
% PMTKndims 10
