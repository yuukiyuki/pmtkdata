% PMTKdescription Images of faces
% PMTKsource http://www.cs.toronto.edu/~roweis/data.html
% PMTKtype Classification
% PMTKncases 400
% PMTKndims 64x64
