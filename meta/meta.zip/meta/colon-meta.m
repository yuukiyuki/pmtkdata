% PMTKdescription Princeton genomics Alon et al colon cancer data
% PMTKsource http://genomics-pubs.princeton.edu/oncology/affydata/index.html
% PMTKtypeX cts
% PMTKtypeY binary
% PMTKncases 62
% PMTKndims 2000
% PMTKcreated processColonData.m