% PMTKdescription A collection of tiny images all roughly 30x30
% PMTKsource google images
% PMTKtypeX 
% PMTKtypeY 
% PMTKncases 
% PMTKndims 
